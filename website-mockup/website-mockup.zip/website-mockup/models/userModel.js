// Placeholder model (not using a real DB yet)
class User {
  constructor(name, email, password) {
    this.name = name;
    this.email = email;
    this.password = password;
  }
}

module.exports = User;
